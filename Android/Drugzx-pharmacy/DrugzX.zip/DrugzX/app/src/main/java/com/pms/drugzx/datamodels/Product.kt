package com.pms.drugzx.datamodels


data class Product(val productName: String,
                   val productId: String,
                   var isProductChecked:Boolean
) {


}