package com.pms.drugzx.ui.login

import androidx.lifecycle.ViewModel
import com.pms.drugzx.datamodels.Login
import com.pms.drugzx.utils.InjectorUtils

class LoginVM: ViewModel() {
var loginRepository= InjectorUtils.provideLoginRepository()
    fun getLoginInfo() = loginRepository.getLoginInfo()

    fun setLoginInfo(login: Login) = loginRepository.setLoginInfo(login)
}