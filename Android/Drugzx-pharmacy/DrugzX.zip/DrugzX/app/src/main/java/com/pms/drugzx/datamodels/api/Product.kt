package com.pms.drugzx.datamodels.api

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class Product(
@Expose
@SerializedName("pId")
val productId: Int? = null,

@Expose
@SerializedName("pName")
val productName: String? = null,
@Expose
@SerializedName("pDescription")
val productDescription: String? = null,
@Expose
@SerializedName("pManufactureDate")
val productManufactureDate: String? = null,
@Expose
@SerializedName("pExpiryDate")
val productExpiryDate: String? = null,
@Expose
@SerializedName("pQuantity")
val productQuantity: Int? = null,
@Expose
@SerializedName("pSellingPrice")
val productSellingPrice: Double? = null,
@Expose
@SerializedName("pCostPrice")
val productCostPrice: Double? = null,
@Expose
@SerializedName("sId")
val productSId: Int? = null

){
    override fun toString(): String {
        return "User(product_id=$product_id, productname=$productname, price=$price)"
    }

}