package com.pms.drugzx.datamodels

  data class Login(val username: String,
                             val password: String) {


}